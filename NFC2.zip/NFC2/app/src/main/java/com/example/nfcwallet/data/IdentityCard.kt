package com.example.nfcwallet.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class IdentityCard(
    val documentNumber: String,
    val name: String,
    val surname: String,
    val birthDate: String,
    val gender: String,
    val nationality: String,
    val validUntil: String,
    val personalNumber: String,
) : Parcelable 