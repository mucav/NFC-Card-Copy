package com.example.nfcwallet.data

object CardManager {
    private var selectedCard: Card? = null

    fun setSelectedCard(card: Card?) {
        selectedCard = card
    }

    fun getSelectedCard(): Card? {
        return selectedCard
    }

    fun clearSelection() {
        selectedCard = null
    }
} 