package com.example.nfcwallet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.nfcwallet.data.IdentityCard
import com.example.nfcwallet.databinding.FragmentIdentityDetailsBinding

class IdentityDetailsFragment : Fragment() {
    private var _binding: FragmentIdentityDetailsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentIdentityDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Kimlik bilgilerini göster
        arguments?.getParcelable<IdentityCard>("identity")?.let { identity ->
            binding.documentNumberText.text = "Belge No: ${identity.documentNumber}"
            binding.nameText.text = "Ad: ${identity.name}"
            binding.surnameText.text = "Soyad: ${identity.surname}"
            binding.birthDateText.text = "Doğum Tarihi: ${identity.birthDate}"
            binding.genderText.text = "Cinsiyet: ${identity.gender}"
            binding.nationalityText.text = "Uyruk: ${identity.nationality}"
            binding.validUntilText.text = "Geçerlilik Tarihi: ${identity.validUntil}"
            binding.personalNumberText.text = "TC Kimlik No: ${identity.personalNumber}"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        fun newInstance(identity: IdentityCard) = IdentityDetailsFragment().apply {
            arguments = Bundle().apply {
                putParcelable("identity", identity)
            }
        }
    }
} 