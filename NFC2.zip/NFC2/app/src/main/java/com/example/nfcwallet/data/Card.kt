package com.example.nfcwallet.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cards")
data class Card(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val cardData: ByteArray,
    val cardType: String,
    val additionalData: String? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Card

        if (id != other.id) return false
        if (name != other.name) return false
        if (!cardData.contentEquals(other.cardData)) return false
        if (cardType != other.cardType) return false
        if (additionalData != other.additionalData) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id
        result = 31 * result + name.hashCode()
        result = 31 * result + cardData.contentHashCode()
        result = 31 * result + cardType.hashCode()
        result = 31 * result + (additionalData?.hashCode() ?: 0)
        return result
    }
} 