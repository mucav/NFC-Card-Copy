package com.example.nfcwallet

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.nfcwallet.data.Card
import com.example.nfcwallet.data.CardManager
import com.example.nfcwallet.databinding.ItemCardBinding

class CardAdapter(
    private val onDeleteClick: (Card) -> Unit,
    private val onCardClick: (Card) -> Unit,
    private val onViewDetails: (Card) -> Unit
) : ListAdapter<Card, CardAdapter.CardViewHolder>(CardDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val binding = ItemCardBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CardViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CardViewHolder(private val binding: ItemCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(card: Card) {
            val isSelected = card.id == CardManager.getSelectedCard()?.id
            
            // Seçim göstergesini göster/gizle
            binding.selectedIndicator.visibility = if (isSelected) {
                android.view.View.VISIBLE
            } else {
                android.view.View.GONE
            }

            binding.cardNameTextView.text = card.name
            
            // Detaylar butonu tıklama
            binding.detailsButton.setOnClickListener { view ->
                val popup = PopupMenu(view.context, view)
                popup.menuInflater.inflate(R.menu.card_details_menu, popup.menu)
                
                popup.setOnMenuItemClickListener { menuItem ->
                    when (menuItem.itemId) {
                        R.id.action_view_details -> {
                            onViewDetails(card)
                            true
                        }
                        R.id.action_delete -> {
                            onDeleteClick(card)
                            true
                        }
                        else -> false
                    }
                }
                popup.show()
            }

            // Kart seçme
            binding.cardView.setOnClickListener {
                onCardClick(card)
                notifyDataSetChanged()
            }

            // Uzun basma ile silme
            binding.cardView.setOnLongClickListener {
                onDeleteClick(card)
                true
            }
        }
    }

    private class CardDiffCallback : DiffUtil.ItemCallback<Card>() {
        override fun areItemsTheSame(oldItem: Card, newItem: Card): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Card, newItem: Card): Boolean {
            return oldItem == newItem
        }
    }
} 