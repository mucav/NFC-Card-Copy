package com.example.nfcwallet

import android.app.PendingIntent
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.nfcwallet.data.AppDatabase
import com.example.nfcwallet.data.Card
import com.example.nfcwallet.data.CardManager
import com.example.nfcwallet.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var nfcAdapter: NfcAdapter
    private lateinit var pendingIntent: PendingIntent
    private lateinit var database: AppDatabase
    private lateinit var cardAdapter: CardAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        // Initialize NFC adapter
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
            ?: run {
                Toast.makeText(this, "NFC desteklenmiyor", Toast.LENGTH_LONG).show()
                finish()
                return
            }

        // Initialize pending intent for NFC
        pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_MUTABLE
        )

        // Initialize database
        database = AppDatabase.getDatabase(this)

        // Setup RecyclerView
        setupRecyclerView()

        // Setup FAB
        binding.addCardFab.setOnClickListener {
            enableNFCReading()
            Toast.makeText(this, "NFC kartını okutun", Toast.LENGTH_LONG).show()
        }

        // Observe cards
        lifecycleScope.launch {
            database.cardDao().getAllCards().collect { cards ->
                cardAdapter.submitList(cards)
                // İlk kartı otomatik olarak seç eğer seçili kart yoksa
                if (CardManager.getSelectedCard() == null && cards.isNotEmpty()) {
                    CardManager.setSelectedCard(cards[0])
                    cardAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun setupRecyclerView() {
        cardAdapter = CardAdapter(
            onDeleteClick = { card -> deleteCard(card) },
            onCardClick = { card ->
                CardManager.setSelectedCard(card)
                Toast.makeText(this, "${card.name} kartı seçildi", Toast.LENGTH_SHORT).show()
            },
            onViewDetails = { card -> showCardDetails(card) }
        )
        binding.cardsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = cardAdapter
        }
    }

    private fun showCardDetails(card: Card) {
        try {
            // Normal kart detaylarını göster
            val cardIdHex = card.cardData.joinToString("") { "%02X".format(it) }
            MaterialAlertDialogBuilder(this)
                .setTitle("Kart Detayları")
                .setMessage("Kart ID: $cardIdHex\nKart Tipi: ${card.cardType}")
                .setPositiveButton("Tamam", null)
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Kart detayları gösterilirken hata oluştu: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun parseIdentityData(data: String): Map<String, String> {
        // additionalData string'ini Map'e dönüştür
        return try {
            data.trim('{', '}')
                .split(", ")
                .map { it.split("=") }
                .associate { it[0] to it[1] }
        } catch (e: Exception) {
            mapOf()
        }
    }

    private fun showIdentityDetailsDialog(data: Map<String, String>) {
        val message = buildString {
            append("TC Kimlik No: ${data["personalNumber"] ?: "Bilinmiyor"}\n")
            append("İsim: ${data["name"] ?: "Bilinmiyor"}\n")
            // Diğer kimlik bilgilerini ekle...
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Kimlik Kartı Detayları")
            .setMessage(message)
            .setPositiveButton("Tamam", null)
            .show()
    }

    private fun enableNFCReading() {
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, null, null)
    }

    private fun disableNFCReading() {
        nfcAdapter.disableForegroundDispatch(this)
    }

    override fun onResume() {
        super.onResume()
        enableNFCReading()
    }

    override fun onPause() {
        super.onPause()
        disableNFCReading()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (NfcAdapter.ACTION_TAG_DISCOVERED == intent.action) {
            val tag: Tag? = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
            tag?.let { processTag(it) }
        }
    }

    private fun processTag(tag: Tag) {
        val isoDep = IsoDep.get(tag)
        if (isoDep != null) {
            try {
                isoDep.connect()
                val cardData = isoDep.tag.id
                
                // Normal kart olarak kaydet
                showSaveCardDialog(cardData)
                
                isoDep.close()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this, "Kart okuma hatası: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Bu kart tipi desteklenmiyor", Toast.LENGTH_SHORT).show()
        }
    }

    private fun readIdentityData(isoDep: IsoDep): Map<String, String> {
        val data = mutableMapOf<String, String>()
        
        try {
            // Kimlik numarası oku
            val readPersonalNumber = byteArrayOf(0x00.toByte(), 0xB0.toByte(), 0x00.toByte(), 0x00.toByte(), 0x08.toByte())
            val personalNumberResponse = isoDep.transceive(readPersonalNumber)
            data["personalNumber"] = String(personalNumberResponse.dropLast(2).toByteArray())

            // İsim oku
            val readName = byteArrayOf(0x00.toByte(), 0xB0.toByte(), 0x00.toByte(), 0x08.toByte(), 0x20.toByte())
            val nameResponse = isoDep.transceive(readName)
            data["name"] = String(nameResponse.dropLast(2).toByteArray()).trim()

            // Diğer verileri oku...
            
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        return data
    }

    private fun saveIdentityCard(cardData: ByteArray, identityData: Map<String, String>) {
        val input = TextInputEditText(this).apply {
            hint = "Kimlik Kartı İsmi"
            setText("Kimlik Kartı")
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Kimlik Kartı Tespit Edildi")
            .setMessage("Bu kart bir kimlik kartı olarak tespit edildi. Kaydetmek istiyor musunuz?")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val cardName = input.text.toString()
                if (cardName.isNotEmpty()) {
                    lifecycleScope.launch {
                        val card = Card(
                            name = cardName,
                            cardData = cardData,
                            cardType = "Identity",
                            additionalData = identityData.toString()
                        )
                        database.cardDao().insertCard(card)
                        Toast.makeText(this@MainActivity, "Kimlik kartı kaydedildi", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun showSaveCardDialog(cardData: ByteArray) {
        val input = TextInputEditText(this).apply {
            hint = "Kart İsmi"
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Kart İsmi Girin")
            .setView(input)
            .setPositiveButton("Kaydet") { _, _ ->
                val cardName = input.text.toString()
                if (cardName.isNotEmpty()) {
                    saveCard(cardName, cardData)
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    private fun saveCard(name: String, cardData: ByteArray) {
        lifecycleScope.launch {
            try {
                val card = Card(name = name, cardData = cardData, cardType = "ISO/IEC 14443-4")
                database.cardDao().insertCard(card)
                Toast.makeText(this@MainActivity, "Kart kaydedildi", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@MainActivity, "Kart kaydedilirken hata oluştu: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun deleteCard(card: Card) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Kartı Sil")
            .setMessage("Bu kartı silmek istediğinizden emin misiniz?")
            .setPositiveButton("Sil") { _, _ ->
                lifecycleScope.launch {
                    database.cardDao().deleteCard(card)
                    // Eğer silinen kart seçili kartsa, seçimi güncelle
                    if (CardManager.getSelectedCard()?.id == card.id) {
                        val remainingCards = database.cardDao().getAllCards().first()
                        if (remainingCards.isNotEmpty()) {
                            CardManager.setSelectedCard(remainingCards[0])
                            cardAdapter.notifyDataSetChanged()
                        } else {
                            CardManager.clearSelection()
                        }
                    }
                    Toast.makeText(this@MainActivity, "Kart silindi", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("İptal", null)
            .show()
    }
} 