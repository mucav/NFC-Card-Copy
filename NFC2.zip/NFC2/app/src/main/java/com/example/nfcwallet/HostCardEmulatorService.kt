package com.example.nfcwallet

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import android.util.Log
import com.example.nfcwallet.data.AppDatabase
import com.example.nfcwallet.data.CardManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

class HostCardEmulatorService : HostApduService() {
    private var currentCard: ByteArray? = null
    private val TAG = "HCEService"

    // ISO-DEP command HEADER for selecting an AID
    private val CLA_INS_P1_P2 = byteArrayOf(0x00.toByte(), 0xA4.toByte(), 0x04.toByte(), 0x00.toByte())
    private val AID_SELECT_OK = byteArrayOf(0x90.toByte(), 0x00.toByte())
    private val AID_SELECT_WRONG = byteArrayOf(0x6A.toByte(), 0x82.toByte())
    private val UNKNOWN_CMD = byteArrayOf(0x6D.toByte(), 0x00.toByte())

    override fun onDeactivated(reason: Int) {
        Log.d(TAG, "Deactivated: $reason")
    }

    override fun processCommandApdu(commandApdu: ByteArray?, extras: Bundle?): ByteArray {
        if (commandApdu == null) {
            return UNKNOWN_CMD
        }

        val hexCmd = commandApdu.joinToString("") { "%02X".format(it) }
        Log.d(TAG, "Received APDU: $hexCmd")

        // Eğer seçili kart yoksa, kartı al
        if (currentCard == null) {
            runBlocking {
                val database = AppDatabase.getDatabase(this@HostCardEmulatorService)
                val selectedCard = CardManager.getSelectedCard()
                if (selectedCard != null) {
                    currentCard = selectedCard.cardData
                    Log.d(TAG, "Selected card loaded: ${currentCard?.joinToString("") { "%02X".format(it) }}")
                }
            }
        }

        // SELECT AID command
        if (commandApdu.size >= 5 && 
            commandApdu[0] == CLA_INS_P1_P2[0] && 
            commandApdu[1] == CLA_INS_P1_P2[1] && 
            commandApdu[2] == CLA_INS_P1_P2[2] && 
            commandApdu[3] == CLA_INS_P1_P2[3]) {
            
            if (currentCard != null) {
                Log.d(TAG, "SELECT AID: OK")
                return AID_SELECT_OK
            } else {
                Log.d(TAG, "SELECT AID: WRONG - No card selected")
                return AID_SELECT_WRONG
            }
        }

        // READ RECORD command veya diğer komutlar
        if (currentCard != null) {
            // Kart verilerini gönder
            Log.d(TAG, "Sending card data")
            return currentCard!! + byteArrayOf(0x90.toByte(), 0x00.toByte())
        }

        Log.d(TAG, "Unknown command")
        return UNKNOWN_CMD
    }
} 